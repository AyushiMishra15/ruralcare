const mongoose = require("mongoose");

const emergencySchema = new mongoose.Schema({
  patientName: String,
  contactNumber: String,
  location: String,
  description: String,
  status: {
    type: String,
    default: "Pending"
  }
}, { timestamps: true });

module.exports = mongoose.model("Emergency", emergencySchema);