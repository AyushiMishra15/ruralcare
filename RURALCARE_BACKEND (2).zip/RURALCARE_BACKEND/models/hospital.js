const mongoose = require("mongoose");

const hospitalSchema = new mongoose.Schema({
  name: String,
  location: String,
  contact: String,
  facilities: [String]
}, { timestamps: true });

module.exports = mongoose.model("Hospital", hospitalSchema);