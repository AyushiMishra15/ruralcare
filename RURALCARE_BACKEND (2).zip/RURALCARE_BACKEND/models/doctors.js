const mongoose = require("mongoose");

const doctorSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true
  },
  specialization: {
    type: String,
    required: true
  },
  hospital: {
    type: String
  },
  contact: {
    type: String
  },
  experience: {
    type: Number
  }
}, { timestamps: true });

module.exports = mongoose.model("Doctor", doctorSchema);