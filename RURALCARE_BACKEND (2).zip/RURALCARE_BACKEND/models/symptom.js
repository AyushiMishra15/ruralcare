const mongoose = require("mongoose");

const symptomSchema = new mongoose.Schema({
  patientName: String,
  symptoms: String,
  duration: String,
  urgencyLevel: {
    type: String,
    enum: ["Low", "Medium", "High"],
    required: true
  }
}, { timestamps: true });

module.exports = mongoose.model("Symptom", symptomSchema);