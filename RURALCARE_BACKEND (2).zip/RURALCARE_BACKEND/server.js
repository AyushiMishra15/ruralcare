const express = require("express");
const cors = require("cors");

require("dotenv").config();


console.log("Mongo URI is:", process.env.MONGO_URI);

const connectDB = require("./config/database");

const app = express();

// Connect to MongoDB
connectDB();

// Middleware
app.use(cors());
app.use(express.json());
app.use("/api/auth", require("./routes/auth"));

// Routes

app.use("/api/auth", require("./routes/auth"));
app.use("/api/hospital", require("./routes/hospital"));
app.use("/api/emergency", require("./routes/emergency"));
app.use("/api/symptoms", require("./routes/symptoms"));
app.use("/api/doctors", require("./routes/doctors"));


// Test Route
app.get("/", (req, res) => {
  res.send("RuralCare API Running...");
});

// Server
const PORT = process.env.PORT || 5000;

app.listen(process.env.PORT || 5000, () => {
  console.log(` Server running on port ${PORT}`);
});