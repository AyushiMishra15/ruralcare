const express = require("express");
const router = express.Router();
const Hospital = require("../models/hospital");

// Add hospital
router.post("/", async (req, res) => {
  try {
    const hospital = await Hospital.create(req.body);
    res.status(201).json(hospital);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Get all hospitals
router.get("/", async (req, res) => {
  const hospitals = await Hospital.find();
  res.json(hospitals);
});

module.exports = router;