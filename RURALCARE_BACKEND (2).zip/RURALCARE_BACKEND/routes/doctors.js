const express = require("express");
const router = express.Router();

// Test GET route
router.get("/", (req, res) => {
  res.json([
    {
      name: "Dr. Sharma",
      specialty: "General Physician",
      location: "Delhi"
    },
    {
      name: "Dr. Mehta",
      specialty: "Cardiologist",
      location: "Mumbai"
    }
  ]);
});

module.exports = router;