const express = require("express");
const router = express.Router();
const Symptom = require("../models/symptom");

// Add symptom
router.post("/", async (req, res) => {
  try {
    const symptom = await Symptom.create(req.body);
    res.status(201).json(symptom);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Get all symptoms
router.get("/", async (req, res) => {
  const symptoms = await Symptom.find();
  res.json(symptoms);
});

module.exports = router;