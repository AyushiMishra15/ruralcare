const express = require("express");
const router = express.Router();
const Emergency = require("../models/emergency");

// Create emergency alert
router.post("/", async (req, res) => {
  try {
    const emergency = await Emergency.create(req.body);
    res.status(201).json(emergency);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Get all emergency alerts
router.get("/", async (req, res) => {
  const emergencies = await Emergency.find();
  res.json(emergencies);
});

module.exports = router;